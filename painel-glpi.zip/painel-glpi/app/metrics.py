"""Definicao e calculo das metricas do painel."""
from collections import defaultdict
from datetime import datetime

STATUS = {1: "Novo", 2: "Em atendimento", 3: "Planejado", 4: "Pendente",
          5: "Aguardando aprovação", 6: "Fechado"}

# kind: series (1 serie), multi (varias series), kpi (numero), table (tabela)
METRICS = [
    # Indicadores (cartoes)
    {"id": "kpi_abertos", "group": "Indicadores", "kind": "kpi", "title": "Abertos no período",
     "help": "Chamados abertos no período selecionado."},
    {"id": "kpi_em_aberto", "group": "Indicadores", "kind": "kpi", "title": "Em aberto agora",
     "help": "Chamados não solucionados neste momento (ignora o período)."},
    {"id": "kpi_pendentes", "group": "Indicadores", "kind": "kpi", "title": "Pendentes agora",
     "help": "Chamados com status Pendente neste momento (ignora o período)."},
    {"id": "kpi_aguardando", "group": "Indicadores", "kind": "kpi", "title": "Aguardando aprovação",
     "help": "Chamados solucionados aguardando aprovação do cliente (ignora o período)."},
    {"id": "kpi_sla_expirado", "group": "Indicadores", "kind": "kpi", "title": "SLA expirado (em aberto)",
     "help": "Chamados em aberto com prazo de solução vencido (ignora o período)."},
    {"id": "kpi_fechados", "group": "Indicadores", "kind": "kpi", "title": "Fechados no período",
     "help": "Chamados fechados dentro do período."},
    {"id": "kpi_reabertos", "group": "Indicadores", "kind": "kpi", "title": "Reabertos",
     "help": "Chamados abertos no período com solução recusada pelo cliente."},
    {"id": "kpi_sla_percentual", "group": "Indicadores", "kind": "kpi", "title": "SLA cumprido",
     "help": "% de chamados solucionados no período dentro do prazo de solução."},
    {"id": "kpi_tempo_medio", "group": "Indicadores", "kind": "kpi", "title": "Tempo médio de solução",
     "help": "Média em horas úteis (calendário do GLPI) dos chamados solucionados no período."},
    {"id": "kpi_novos_sem_tecnico", "group": "Indicadores", "kind": "kpi", "title": "Novos sem técnico",
     "help": "Chamados novos ainda sem técnico atribuído (ignora filtros)."},

    # Visao geral
    {"id": "status_geral", "group": "Visão geral", "kind": "series", "title": "Chamados por status",
     "help": "Chamados abertos no período, agrupados pelo status atual."},
    {"id": "sla_geral", "group": "Visão geral", "kind": "series", "title": "Situação do SLA",
     "help": "Chamados abertos no período, agrupados pela situação do prazo de solução."},
    {"id": "evolucao", "group": "Visão geral", "kind": "multi", "title": "Abertos x Solucionados x Fechados",
     "help": "Evolução diária (ou mensal, em períodos acima de 2 meses)."},

    # Por tecnico
    {"id": "status_por_tecnico", "group": "Por técnico", "kind": "multi", "title": "Status por técnico",
     "help": "Chamados abertos no período, por técnico e status atual."},
    {"id": "em_aberto_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Em aberto por técnico",
     "help": "Fila atual de cada técnico (ignora o período)."},
    {"id": "pendentes_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Pendentes por técnico",
     "help": "Chamados Pendentes agora (ignora o período)."},
    {"id": "aguardando_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Aguardando aprovação por técnico",
     "help": "Solucionados aguardando aprovação do cliente (ignora o período)."},
    {"id": "fechados_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Fechados por técnico",
     "help": "Chamados fechados dentro do período."},
    {"id": "reabertos_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Reabertos por técnico",
     "help": "Chamados abertos no período com solução recusada."},
    {"id": "sla_por_tecnico", "group": "Por técnico", "kind": "multi", "title": "SLA por técnico",
     "help": "Chamados com SLA abertos no período: no prazo x expirado."},
    {"id": "sla_percentual_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "% SLA cumprido por técnico",
     "help": "% de solucionados no período dentro do prazo."},
    {"id": "tempo_medio_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Tempo médio de solução (h) por técnico",
     "help": "Média em horas úteis dos chamados solucionados no período."},
    {"id": "validacoes_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Aguardando validação por técnico",
     "help": "Chamados em aberto com validação (aprovação de gestor) pendente."},

    # Tabelas
    {"id": "tabela_ranking", "group": "Tabelas", "kind": "table", "title": "Resumo por técnico",
     "help": "Principais indicadores de cada técnico."},
    {"id": "tabela_sla_expirado", "group": "Tabelas", "kind": "table", "title": "Chamados com SLA expirado",
     "help": "Chamados em aberto com prazo vencido, do mais atrasado ao menos atrasado."},
]

SLA_ORDEM = ["Solucionado no prazo", "Em aberto - no prazo", "Solucionado fora do prazo",
             "Em aberto - expirado", "Sem SLA"]


def _fmt(dt):
    return dt.strftime("%d/%m/%Y %H:%M") if dt else ""


def _media_horas(valores):
    valores = [v for v in valores if v > 0]
    return round(sum(valores) / len(valores) / 3600, 1) if valores else 0


def _chaves_tempo(inicio, fim):
    mensal = (fim.date() - inicio.date()).days > 62
    chaves, rotulos = [], []
    if mensal:
        ano, mes = inicio.year, inicio.month
        while (ano, mes) <= (fim.year, fim.month):
            chaves.append(f"{ano:04d}-{mes:02d}")
            rotulos.append(f"{mes:02d}/{ano}")
            mes += 1
            if mes > 12:
                ano, mes = ano + 1, 1
        return chaves, rotulos, (lambda dt: dt.strftime("%Y-%m"))
    dia = inicio.date()
    while dia <= fim.date():
        chaves.append(dia.isoformat())
        rotulos.append(dia.strftime("%d/%m"))
        dia = dia.fromordinal(dia.toordinal() + 1)
    return chaves, rotulos, (lambda dt: dt.date().isoformat())


def calcular(dados, inicio, fim, filtro_tecnicos):
    agora = datetime.now()
    tecnicos = dados["techs"]
    sel = (set(filtro_tecnicos) & set(tecnicos)) if filtro_tecnicos else set(tecnicos)
    nomes = {u: tecnicos[u]["name"] for u in sel}
    ordem = sorted(sel, key=lambda u: nomes[u].lower())
    rot_tec = [nomes[u] for u in ordem]

    T = [t for t in dados["tickets"] if t["techs"] & sel]

    def no_periodo(dt):
        return dt is not None and inicio <= dt <= fim

    abertos = [t for t in T if no_periodo(t["date"])]
    solucionados = [t for t in T if t["status"] in (5, 6) and no_periodo(t["solvedate"])]
    fechados = [t for t in T if t["status"] == 6 and no_periodo(t["closedate"])]
    em_aberto = [t for t in T if t["status"] not in (5, 6)]

    def por_tecnico(lista, cond=lambda t: True):
        c = defaultdict(int)
        for t in lista:
            if cond(t):
                for u in t["techs"] & sel:
                    c[u] += 1
        return [c[u] for u in ordem]

    def serie(rotulos, valores, nome="Chamados"):
        return {"labels": rotulos, "datasets": [{"label": nome, "data": valores}]}

    def multi(rotulos, series):
        return {"labels": rotulos, "datasets": [{"label": n, "data": v} for n, v in series]}

    def situacao_sla(t):
        if t["ttr"] is None:
            return "Sem SLA"
        if t["status"] in (5, 6):
            ok = t["solvedate"] is not None and t["solvedate"] <= t["ttr"]
            return "Solucionado no prazo" if ok else "Solucionado fora do prazo"
        return "Em aberto - expirado" if agora > t["ttr"] else "Em aberto - no prazo"

    def sla_ok(t):
        return situacao_sla(t) in ("Solucionado no prazo", "Em aberto - no prazo")

    def pct_sla(lista):
        com = [t for t in lista if t["ttr"]]
        if not com:
            return None
        return round(100 * sum(1 for t in com if t["solvedate"] <= t["ttr"]) / len(com), 1)

    m = {}

    # ---------- Indicadores ----------
    m["kpi_abertos"] = {"value": len(abertos)}
    m["kpi_em_aberto"] = {"value": len(em_aberto)}
    m["kpi_pendentes"] = {"value": sum(1 for t in T if t["status"] == 4)}
    m["kpi_aguardando"] = {"value": sum(1 for t in T if t["status"] == 5)}
    m["kpi_sla_expirado"] = {"value": sum(1 for t in em_aberto if t["ttr"] and agora > t["ttr"])}
    m["kpi_fechados"] = {"value": len(fechados)}
    m["kpi_reabertos"] = {"value": sum(1 for t in abertos if t["refused"])}
    m["kpi_sla_percentual"] = {"value": pct_sla(solucionados), "suffix": "%"}
    m["kpi_tempo_medio"] = {"value": _media_horas([t["solve_delay"] for t in solucionados]), "suffix": " h"}
    m["kpi_novos_sem_tecnico"] = {"value": dados["unassigned_new"]}

    # ---------- Visao geral ----------
    cont = defaultdict(int)
    for t in abertos:
        cont[t["status"]] += 1
    st = [s for s in STATUS if cont[s]]
    m["status_geral"] = serie([STATUS[s] for s in st], [cont[s] for s in st])

    cont_sla = defaultdict(int)
    for t in abertos:
        cont_sla[situacao_sla(t)] += 1
    sl = [s for s in SLA_ORDEM if cont_sla[s]]
    m["sla_geral"] = serie(sl, [cont_sla[s] for s in sl])

    chaves, rotulos, chave = _chaves_tempo(inicio, fim)
    a, s, f = defaultdict(int), defaultdict(int), defaultdict(int)
    for t in abertos:
        a[chave(t["date"])] += 1
    for t in solucionados:
        s[chave(t["solvedate"])] += 1
    for t in fechados:
        f[chave(t["closedate"])] += 1
    m["evolucao"] = multi(rotulos, [("Abertos", [a[k] for k in chaves]),
                                    ("Solucionados", [s[k] for k in chaves]),
                                    ("Fechados", [f[k] for k in chaves])])

    # ---------- Por tecnico ----------
    m["status_por_tecnico"] = multi(rot_tec, [
        ("Em atendimento", por_tecnico(abertos, lambda t: t["status"] in (1, 2, 3))),
        ("Pendentes", por_tecnico(abertos, lambda t: t["status"] == 4)),
        ("Aguardando aprovação", por_tecnico(abertos, lambda t: t["status"] == 5)),
        ("Fechados", por_tecnico(abertos, lambda t: t["status"] == 6)),
    ])
    m["em_aberto_por_tecnico"] = serie(rot_tec, por_tecnico(em_aberto), "Em aberto")
    m["pendentes_por_tecnico"] = serie(rot_tec, por_tecnico(T, lambda t: t["status"] == 4), "Pendentes")
    m["aguardando_por_tecnico"] = serie(rot_tec, por_tecnico(T, lambda t: t["status"] == 5),
                                        "Aguardando aprovação")
    m["fechados_por_tecnico"] = serie(rot_tec, por_tecnico(fechados), "Fechados")
    m["reabertos_por_tecnico"] = serie(rot_tec, por_tecnico(abertos, lambda t: t["refused"]), "Reabertos")

    com_sla = [t for t in abertos if t["ttr"]]
    m["sla_por_tecnico"] = multi(rot_tec, [
        ("No prazo", por_tecnico(com_sla, sla_ok)),
        ("Expirado", por_tecnico(com_sla, lambda t: not sla_ok(t))),
    ])
    m["sla_percentual_por_tecnico"] = serie(
        rot_tec, [pct_sla([t for t in solucionados if u in t["techs"]]) or 0 for u in ordem],
        "% SLA cumprido")
    m["tempo_medio_por_tecnico"] = serie(
        rot_tec, [_media_horas([t["solve_delay"] for t in solucionados if u in t["techs"]]) for u in ordem],
        "Horas (média)")
    m["validacoes_por_tecnico"] = serie(
        rot_tec, por_tecnico(em_aberto, lambda t: t["waiting_validation"]), "Aguardando validação")

    # ---------- Tabelas ----------
    linhas = []
    for u in ordem:
        ab = [t for t in abertos if u in t["techs"]]
        so = [t for t in solucionados if u in t["techs"]]
        p = pct_sla(so)
        linhas.append([
            nomes[u],
            len(ab),
            sum(1 for t in fechados if u in t["techs"]),
            sum(1 for t in em_aberto if u in t["techs"]),
            sum(1 for t in T if u in t["techs"] and t["status"] == 4),
            sum(1 for t in T if u in t["techs"] and t["status"] == 5),
            sum(1 for t in ab if t["refused"]),
            "-" if p is None else f"{p}%",
            _media_horas([t["solve_delay"] for t in so]),
        ])
    m["tabela_ranking"] = {
        "columns": ["Técnico", "Abertos (período)", "Fechados (período)", "Em aberto agora",
                    "Pendentes", "Aguard. aprovação", "Reabertos", "SLA cumprido", "Tempo médio (h)"],
        "rows": linhas,
    }

    atrasados = sorted([t for t in em_aberto if t["ttr"] and agora > t["ttr"]], key=lambda t: t["ttr"])
    m["tabela_sla_expirado"] = {
        "columns": ["Chamado", "Título", "Técnico(s)", "Status", "Abertura", "Prazo SLA", "Atraso (h)"],
        "rows": [[t["id"], t["name"], ", ".join(sorted(nomes[u] for u in t["techs"] & sel)),
                  STATUS.get(t["status"], ""), _fmt(t["date"]), _fmt(t["ttr"]),
                  round((agora - t["ttr"]).total_seconds() / 3600, 1)] for t in atrasados[:500]],
    }
    return m
