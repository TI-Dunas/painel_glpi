/* Painel de Atendimento GLPI - interface */
(function () {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);

  // ------------------------------------------------------------ configuracoes visuais
  const PALETAS = {
    padrao:   { nome: "Padrão",            cores: ["#1f7a8c", "#12324a", "#d98e04", "#2e8b57", "#c0392b", "#7d5ba6", "#4f9fd1", "#a0522d", "#5d6f7d", "#e07a5f"] },
    azul:     { nome: "Tons de azul",      cores: ["#12324a", "#1d5a80", "#2b7bb0", "#4f9fd1", "#86bfe3", "#b9daf0", "#0e2233", "#3d6e8f", "#6aa3c8", "#a4c9e2"] },
    verde:    { nome: "Tons de verde",     cores: ["#2e8b57", "#1e5e3a", "#4caf7a", "#7fcf9f", "#b5e3c6", "#3f7d5a", "#a3c9a8", "#256d47", "#5fbf8a", "#d0efdc"] },
    quente:   { nome: "Quentes",           cores: ["#d98e04", "#e07a5f", "#c0392b", "#f2b134", "#a0522d", "#f4a261", "#8c2f1f", "#e9c46a", "#b5651d", "#ffd6a5"] },
    pastel:   { nome: "Pastel",            cores: ["#7d5ba6", "#8ecae6", "#a3c9a8", "#f4a3a8", "#ffd6a5", "#bdb2ff", "#caffbf", "#fdffb6", "#9bf6ff", "#ffc6ff"] },
    semaforo: { nome: "Por significado (status/SLA)", cores: ["#2e8b57", "#7fcf9f", "#d98e04", "#c0392b", "#9aa8b3", "#4f9fd1", "#7d5ba6", "#12324a", "#e07a5f", "#5d6f7d"] },
    alerta:   { nome: "Alerta",            cores: ["#c0392b", "#d98e04", "#8c2f1f", "#e07a5f", "#f2b134", "#a0522d", "#5d6f7d", "#12324a", "#7d5ba6", "#2e8b57"] },
    cinza:    { nome: "Neutro",            cores: ["#12324a", "#5d6f7d", "#9aa8b3", "#c9d3da", "#2c3e50", "#7f8c8d", "#b0bec5", "#455a64", "#90a4ae", "#cfd8dc"] },
  };

  // Cores fixas usadas pela paleta "Por significado": verde = ok, amarelo = atencao, vermelho = critico
  const SIGNIFICADO = {
    "No prazo": "#2e8b57", "Expirado": "#c0392b", "Solucionado no prazo": "#2e8b57",
    "Em aberto - no prazo": "#7fcf9f", "Solucionado fora do prazo": "#d98e04",
    "Em aberto - expirado": "#c0392b", "Sem SLA": "#9aa8b3",
    "Novo": "#4f9fd1", "Em atendimento": "#1f7a8c", "Planejado": "#7d5ba6", "Pendente": "#d98e04",
    "Pendentes": "#d98e04", "Aguardando aprovação": "#f2b134", "Fechado": "#2e8b57", "Fechados": "#2e8b57",
    "Em aberto": "#1f7a8c", "Abertos": "#1f7a8c", "Solucionados": "#7d5ba6", "Reabertos": "#c0392b",
  };

  const TIPOS = {
    series: [["pie", "Pizza"], ["doughnut", "Rosca"], ["polarArea", "Polar"], ["bar", "Barras verticais"],
             ["barh", "Barras horizontais"], ["line", "Linha"], ["area", "Área"], ["table", "Tabela"]],
    multi:  [["bar", "Barras agrupadas"], ["stacked", "Barras empilhadas"], ["barh", "Barras horizontais"],
             ["barh_stacked", "Barras horizontais empilhadas"], ["line", "Linhas"], ["area", "Áreas"],
             ["radar", "Radar"], ["table", "Tabela"]],
    kpi:    [["card", "Cartão com número"]],
    table:  [["table", "Tabela"]],
  };

  const ALTURAS = { P: 150, M: 330, G: 470 };

  const estado = {
    metricas: [], porId: {}, painel: { widgets: [] }, dados: null,
    tecnicos: [], selecionados: new Set(), editando: false, graficos: [], editandoId: null,
  };

  // ------------------------------------------------------------ utilitarios
  async function api(url, opcoes) {
    const r = await fetch(url, opcoes);
    let j = null;
    try { j = await r.json(); } catch (e) { /* sem corpo */ }
    if (!r.ok) throw new Error((j && (j.detail || j.message)) || `Erro HTTP ${r.status}`);
    return j;
  }
  const post = (url, corpo) => api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) });

  const fmtNum = (v) => (typeof v === "number" ? v.toLocaleString("pt-BR") : v);
  const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const novoId = () => Math.random().toString(16).slice(2, 10);
  const salvarLocal = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignora */ } };
  const lerLocal = (k, p) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : p; } catch (e) { return p; } };

  function hexA(hex, a) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
  }

  function aviso(msg) {
    const el = $("#aviso");
    el.hidden = !msg;
    el.textContent = msg || "";
  }

  // ------------------------------------------------------------ periodo
  function aplicarPreset(p) {
    const hoje = new Date();
    let ini = new Date(hoje), fim = new Date(hoje);
    if (p === "hoje") { /* mesmo dia */ }
    else if (p === "mes") ini = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    else if (p === "mes_ant") { ini = new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1); fim = new Date(hoje.getFullYear(), hoje.getMonth(), 0); }
    else if (p === "ano") ini = new Date(hoje.getFullYear(), 0, 1);
    else if (p === "custom") return;
    else ini.setDate(hoje.getDate() - (parseInt(p, 10) - 1));
    $("#inicio").value = iso(ini);
    $("#fim").value = iso(fim);
  }

  // ------------------------------------------------------------ plugin: valores no grafico
  const pluginValores = {
    id: "valores",
    afterDatasetsDraw(chart, args, opts) {
      if (!opts || !opts.enabled) return;
      const { ctx } = chart;
      const redondo = ["pie", "doughnut", "polarArea"].includes(chart.config.type);
      const horizontal = chart.options.indexAxis === "y";
      ctx.save();
      ctx.font = "600 11px 'Segoe UI', system-ui, sans-serif";
      ctx.textBaseline = "middle";
      chart.data.datasets.forEach((ds, i) => {
        const meta = chart.getDatasetMeta(i);
        if (meta.hidden) return;
        meta.data.forEach((el, j) => {
          const v = ds.data[j];
          if (v === null || v === undefined || v === 0 || !chart.getDataVisibility(j)) return;
          const p = el.tooltipPosition();
          let x = p.x, y = p.y;
          ctx.textAlign = "center";
          ctx.fillStyle = redondo ? "#ffffff" : "#1d2b36";
          if (!redondo) {
            if (chart.config.type === "bar" && horizontal) { ctx.textAlign = "left"; x += 4; }
            else y -= 9;
          }
          ctx.fillText(fmtNum(v), x, y);
        });
      });
      ctx.restore();
    },
  };
  if (window.Chart) Chart.register(pluginValores);

  // ------------------------------------------------------------ renderizacao
  function destruirGraficos() {
    estado.graficos.forEach((g) => g.destroy());
    estado.graficos = [];
  }

  function renderizar() {
    destruirGraficos();
    const grade = $("#grade");
    grade.innerHTML = "";
    grade.classList.toggle("editando", estado.editando);
    if (!estado.painel.widgets.length) {
      grade.innerHTML = '<div class="w-12 vazio" style="padding:60px">O painel está vazio. Clique em "Editar painel" e depois em "Adicionar gráfico".</div>';
      return;
    }
    estado.painel.widgets.forEach((w, idx) => grade.appendChild(criarPainel(w, idx)));
  }

  function criarPainel(w, idx) {
    const meta = estado.porId[w.metric];
    const el = document.createElement("section");
    el.className = `painel w-${w.width}`;
    el.style.height = `${ALTURAS[w.height] || ALTURAS.M}px`;

    const topo = document.createElement("div");
    topo.className = "painel-topo";
    const titulo = document.createElement("h3");
    titulo.className = "painel-titulo";
    titulo.textContent = w.title;
    if (meta) titulo.title = meta.help;
    topo.appendChild(titulo);

    if (estado.editando) {
      const f = document.createElement("div");
      f.className = "ferramentas";
      [["←", "Mover para trás", () => mover(idx, -1)], ["→", "Mover para frente", () => mover(idx, 1)],
       ["✎", "Editar gráfico", () => abrirEditor(w.id)], ["✕", "Remover gráfico", () => remover(idx)]]
        .forEach(([txt, dica, fn]) => {
          const b = document.createElement("button");
          b.type = "button"; b.textContent = txt; b.title = dica; b.setAttribute("aria-label", dica);
          b.addEventListener("click", fn);
          f.appendChild(b);
        });
      topo.appendChild(f);
    }
    el.appendChild(topo);

    const corpo = document.createElement("div");
    corpo.className = "painel-corpo";
    el.appendChild(corpo);

    const d = estado.dados && estado.dados.metrics ? estado.dados.metrics[w.metric] : null;
    if (!meta) { corpo.innerHTML = '<div class="vazio">Métrica não encontrada. Edite este gráfico.</div>'; return el; }
    if (!d) { corpo.innerHTML = `<div class="vazio">${estado.dados ? "Sem dados." : "Aguardando dados…"}</div>`; return el; }

    if (meta.kind === "kpi") desenharKpi(el, corpo, w, d);
    else if (meta.kind === "table") desenharTabela(corpo, d.columns, d.rows);
    else if (!d.labels.length || d.datasets.every((ds) => ds.data.every((v) => !v))) corpo.innerHTML = '<div class="vazio">Nenhum chamado para os filtros selecionados.</div>';
    else if (w.type === "table") desenharTabela(corpo, [""].concat(d.datasets.map((x) => x.label)), d.labels.map((l, i) => [l].concat(d.datasets.map((x) => x.data[i]))));
    else desenharGrafico(corpo, w, d, meta.kind);
    return el;
  }

  function desenharKpi(painel, corpo, w, d) {
    painel.classList.add("kpi");
    const cor = (PALETAS[w.palette] || PALETAS.padrao).cores[0];
    painel.style.setProperty("--kpi-cor", cor);
    const v = document.createElement("div");
    v.className = "kpi-valor";
    v.textContent = d.value === null || d.value === undefined ? "–" : fmtNum(d.value);
    if (d.suffix && d.value !== null && d.value !== undefined) {
      const s = document.createElement("span");
      s.className = "kpi-sufixo"; s.textContent = d.suffix.trim();
      v.appendChild(s);
    }
    corpo.appendChild(v);
  }

  function desenharTabela(corpo, colunas, linhas) {
    if (!linhas.length) { corpo.innerHTML = '<div class="vazio">Nenhum registro.</div>'; return; }
    const wrap = document.createElement("div");
    wrap.className = "tabela-wrap";
    const tabela = document.createElement("table");
    const numerica = colunas.map((_, i) => linhas.every((l) => typeof l[i] === "number" || /^-?[\d.,]+%?$/.test(String(l[i]))));
    const thead = document.createElement("thead");
    const trh = document.createElement("tr");
    let ordemCol = -1, asc = true;
    const tbody = document.createElement("tbody");

    function preencher(dados) {
      tbody.innerHTML = "";
      dados.forEach((l) => {
        const tr = document.createElement("tr");
        l.forEach((c, i) => {
          const td = document.createElement("td");
          td.textContent = typeof c === "number" ? fmtNum(c) : c;
          if (numerica[i]) td.className = "num";
          else if (String(c).length > 40) td.className = "texto";
          tr.appendChild(td);
        });
        tbody.appendChild(tr);
      });
    }
    const valor = (x) => { const n = parseFloat(String(x).replace("%", "")); return isNaN(n) ? String(x).toLowerCase() : n; };

    colunas.forEach((c, i) => {
      const th = document.createElement("th");
      th.textContent = c;
      th.title = "Clique para ordenar";
      if (numerica[i]) th.className = "num";
      th.addEventListener("click", () => {
        asc = ordemCol === i ? !asc : true;
        ordemCol = i;
        preencher(linhas.slice().sort((a, b) => {
          const x = valor(a[i]), y = valor(b[i]);
          return (x > y ? 1 : x < y ? -1 : 0) * (asc ? 1 : -1);
        }));
      });
      trh.appendChild(th);
    });
    thead.appendChild(trh);
    tabela.append(thead, tbody);
    preencher(linhas);
    wrap.appendChild(tabela);
    corpo.appendChild(wrap);
  }

  function desenharGrafico(corpo, w, d, kind) {
    const canvas = document.createElement("canvas");
    corpo.appendChild(canvas);
    const cores = (PALETAS[w.palette] || PALETAS.padrao).cores;
    const porSignificado = w.palette === "semaforo";
    const cor = (rotulo, i) => (porSignificado && SIGNIFICADO[rotulo]) || cores[i % cores.length];
    let tipo = w.type, eixo = "x", empilhado = false, preencher = false;
    if (tipo === "barh") { tipo = "bar"; eixo = "y"; }
    if (tipo === "stacked") { tipo = "bar"; empilhado = true; }
    if (tipo === "barh_stacked") { tipo = "bar"; eixo = "y"; empilhado = true; }
    if (tipo === "area") { tipo = "line"; preencher = true; }
    const redondo = ["pie", "doughnut", "polarArea"].includes(tipo);
    const coresPorItem = redondo || (kind === "series" && tipo === "bar");

    const datasets = d.datasets.map((ds, i) => {
      const base = { label: ds.label, data: ds.data };
      if (coresPorItem) {
        const c = d.labels.map((l, j) => cor(l, j));
        return { ...base, backgroundColor: redondo && tipo === "polarArea" ? c.map((x) => hexA(x, 0.75)) : c,
                 borderColor: redondo ? "#ffffff" : c, borderWidth: redondo ? 2 : 0, borderRadius: redondo ? 0 : 3 };
      }
      const c = cor(ds.label, i);
      if (tipo === "line") return { ...base, borderColor: c, backgroundColor: preencher ? hexA(c, 0.22) : c, fill: preencher, tension: 0.3, pointRadius: 2, borderWidth: 2 };
      if (tipo === "radar") return { ...base, borderColor: c, backgroundColor: hexA(c, 0.2), pointBackgroundColor: c };
      return { ...base, backgroundColor: c, borderRadius: 3 };
    });

    const mostrarLegenda = !!w.legend && (redondo || datasets.length > 1);
    const opcoes = {
      responsive: true, maintainAspectRatio: false, indexAxis: eixo, animation: { duration: 300 },
      plugins: {
        legend: { display: mostrarLegenda, position: redondo ? "right" : "bottom", labels: { boxWidth: 12, usePointStyle: true } },
        valores: { enabled: !!w.values },
        tooltip: { callbacks: { label: (c) => ` ${c.dataset.label === "Chamados" && redondo ? c.label : c.dataset.label}: ${fmtNum(c.raw)}` } },
      },
    };
    if (w.values && !redondo) opcoes.layout = { padding: eixo === "y" ? { right: 36 } : { top: 18 } };
    if (!redondo && tipo !== "radar") {
      opcoes.scales = {
        x: { stacked: empilhado, beginAtZero: true, grid: { display: eixo === "y" }, ticks: { autoSkip: true, maxRotation: 45 } },
        y: { stacked: empilhado, beginAtZero: true, grid: { display: eixo !== "y" } },
      };
    }
    if (tipo === "radar") opcoes.scales = { r: { beginAtZero: true } };
    estado.graficos.push(new Chart(canvas, { type: tipo, data: { labels: d.labels, datasets }, options: opcoes }));
  }

  // ------------------------------------------------------------ dados
  let temporizador = null;
  async function carregarDados(atualizar = false) {
    const ini = $("#inicio").value, fim = $("#fim").value;
    if (!ini || !fim) return;
    if (ini > fim) { aviso("A data inicial é maior que a data final."); return; }
    const tecnicos = estado.selecionados.size && estado.selecionados.size < estado.tecnicos.length ? [...estado.selecionados].join(",") : "";
    const q = new URLSearchParams({ start: ini, end: fim, techs: tecnicos });
    if (atualizar) q.set("refresh", "true");
    $("#carregando").hidden = false;
    try {
      const d = await api(`/api/data?${q}`);
      estado.dados = d;
      atualizarTecnicos(d.techs);
      $("#atualizado").textContent = d.loaded_at ? `Dados do GLPI de ${d.loaded_at}` : "";
      aviso("");
    } catch (e) {
      aviso(`Não foi possível carregar os dados: ${e.message} Confira a conexão em Configurações.`);
    } finally {
      $("#carregando").hidden = true;
    }
    renderizar();
  }
  const recarregar = () => { clearTimeout(temporizador); temporizador = setTimeout(() => carregarDados(false), 250); };

  // ------------------------------------------------------------ filtro de tecnicos
  function atualizarTecnicos(lista) {
    const primeiraVez = !estado.tecnicos.length;
    estado.tecnicos = lista;
    if (primeiraVez) {
      const salvos = lerLocal("painel.tecnicos", null);
      estado.selecionados = new Set(salvos ? salvos.filter((id) => lista.some((t) => t.id === id)) : lista.map((t) => t.id));
      if (!estado.selecionados.size) estado.selecionados = new Set(lista.map((t) => t.id));
    }
    desenharListaTecnicos();
  }

  function desenharListaTecnicos() {
    const busca = $("#tec-busca").value.trim().toLowerCase();
    const box = $("#tec-itens");
    box.innerHTML = "";
    estado.tecnicos.filter((t) => t.name.toLowerCase().includes(busca)).forEach((t) => {
      const l = document.createElement("label");
      if (!t.active) l.className = "inativo";
      const c = document.createElement("input");
      c.type = "checkbox"; c.checked = estado.selecionados.has(t.id);
      c.addEventListener("change", () => {
        c.checked ? estado.selecionados.add(t.id) : estado.selecionados.delete(t.id);
        mudouTecnicos();
      });
      l.append(c, document.createTextNode(t.name + (t.active ? "" : " (inativo)")));
      box.appendChild(l);
    });
    const n = estado.selecionados.size, total = estado.tecnicos.length;
    $("#btn-tecnicos").textContent = !total || n === total ? "Técnicos: todos" : `Técnicos: ${n} de ${total}`;
  }

  function mudouTecnicos() {
    if (!estado.selecionados.size) estado.selecionados = new Set(estado.tecnicos.map((t) => t.id));
    salvarLocal("painel.tecnicos", [...estado.selecionados]);
    desenharListaTecnicos();
    recarregar();
  }

  // ------------------------------------------------------------ edicao do painel
  async function salvarPainel() {
    try { await post("/api/dashboard", estado.painel); }
    catch (e) { aviso(`Não foi possível salvar o painel: ${e.message}`); }
  }
  function mover(idx, delta) {
    const ws = estado.painel.widgets, alvo = idx + delta;
    if (alvo < 0 || alvo >= ws.length) return;
    [ws[idx], ws[alvo]] = [ws[alvo], ws[idx]];
    salvarPainel(); renderizar();
  }
  function remover(idx) {
    if (!confirm(`Remover o gráfico "${estado.painel.widgets[idx].title}"?`)) return;
    estado.painel.widgets.splice(idx, 1);
    salvarPainel(); renderizar();
  }

  function preencherTipos(kind, atual) {
    const sel = $("#w-tipo");
    sel.innerHTML = "";
    (TIPOS[kind] || TIPOS.series).forEach(([v, n]) => sel.add(new Option(n, v)));
    sel.value = (TIPOS[kind] || []).some(([v]) => v === atual) ? atual : sel.options[0].value;
    const grafico = kind === "series" || kind === "multi";
    $("#w-legenda").disabled = !grafico;
    $("#w-valores").disabled = !grafico;
  }

  function abrirEditor(id) {
    estado.editandoId = id || null;
    const w = id ? estado.painel.widgets.find((x) => x.id === id) : null;
    $("#dlg-widget-titulo").textContent = w ? "Editar gráfico" : "Adicionar gráfico";
    const metrica = w ? w.metric : estado.metricas[0].id;
    $("#w-metrica").value = metrica;
    const meta = estado.porId[metrica];
    $("#w-titulo").value = w ? w.title : meta.title;
    $("#w-ajuda").textContent = meta.help;
    preencherTipos(meta.kind, w ? w.type : null);
    $("#w-paleta").value = w ? w.palette : "padrao";
    $("#w-largura").value = String(w ? w.width : meta.kind === "kpi" ? 3 : 6);
    $("#w-altura").value = w ? w.height : meta.kind === "kpi" ? "P" : "M";
    $("#w-legenda").checked = w ? !!w.legend : true;
    $("#w-valores").checked = w ? !!w.values : false;
    $("#dlg-widget").showModal();
  }

  function salvarEditor() {
    const meta = estado.porId[$("#w-metrica").value];
    const dados = {
      metric: meta.id, title: $("#w-titulo").value.trim() || meta.title, type: $("#w-tipo").value,
      palette: $("#w-paleta").value, width: parseInt($("#w-largura").value, 10), height: $("#w-altura").value,
      legend: $("#w-legenda").checked, values: $("#w-valores").checked,
    };
    if (estado.editandoId) Object.assign(estado.painel.widgets.find((x) => x.id === estado.editandoId), dados);
    else estado.painel.widgets.push({ id: novoId(), ...dados });
    salvarPainel(); renderizar();
  }

  function modoEdicao(ativo) {
    estado.editando = ativo;
    $("#barra-edicao").hidden = !ativo;
    $("#btn-editar").hidden = ativo;
    renderizar();
  }

  // ------------------------------------------------------------ configuracoes
  async function abrirConfig(intro) {
    const c = await api("/api/config");
    $("#cfg-intro").textContent = intro || "Os tokens ficam gravados somente no servidor do painel. Deixe um token em branco para manter o valor já salvo.";
    $("#c-url").value = c.glpi_url || "";
    $("#c-app").value = ""; $("#c-user").value = "";
    $("#c-app").placeholder = c.app_token_set ? "•••••• (salvo; preencha só para trocar)" : "Configurar > Geral > API > Cliente da API";
    $("#c-user").placeholder = c.user_token_set ? "•••••• (salvo; preencha só para trocar)" : "Minhas configurações > Token da API";
    $("#c-app-limpar").checked = false;
    $("#c-perfil").value = c.tech_profile || "Technician";
    $("#c-cache").value = c.cache_minutes || 10;
    $("#c-ssl").checked = !!c.verify_ssl;
    $("#c-resultado").hidden = true;
    $("#dlg-config").showModal();
  }

  function lerFormConfig() {
    return {
      glpi_url: $("#c-url").value.trim(), app_token: $("#c-app").value.trim(), user_token: $("#c-user").value.trim(),
      clear_app_token: $("#c-app-limpar").checked, tech_profile: $("#c-perfil").value.trim() || "Technician",
      cache_minutes: parseInt($("#c-cache").value, 10) || 10, verify_ssl: $("#c-ssl").checked,
    };
  }

  function resultado(ok, msg) {
    const el = $("#c-resultado");
    el.hidden = false;
    el.className = `resultado ${ok ? "ok" : "erro"}`;
    el.textContent = msg;
  }

  // ------------------------------------------------------------ eventos
  function ligarEventos() {
    $("#periodo").addEventListener("change", (e) => {
      const p = e.target.value;
      salvarLocal("painel.periodo", p);
      aplicarPreset(p);
      if (p !== "custom") recarregar();
    });
    ["#inicio", "#fim"].forEach((s) => $(s).addEventListener("change", () => {
      $("#periodo").value = "custom"; salvarLocal("painel.periodo", "custom");
      salvarLocal("painel.datas", [$("#inicio").value, $("#fim").value]);
      recarregar();
    }));

    $("#btn-tecnicos").addEventListener("click", (e) => { e.stopPropagation(); $("#lista-tecnicos").hidden = !$("#lista-tecnicos").hidden; });
    $("#lista-tecnicos").addEventListener("click", (e) => e.stopPropagation());
    document.addEventListener("click", () => { $("#lista-tecnicos").hidden = true; });
    $("#tec-busca").addEventListener("input", desenharListaTecnicos);
    $("#tec-todos").addEventListener("click", () => { estado.selecionados = new Set(estado.tecnicos.map((t) => t.id)); mudouTecnicos(); });
    $("#tec-nenhum").addEventListener("click", () => { estado.selecionados = new Set(); desenharListaTecnicos(); $("#btn-tecnicos").textContent = "Técnicos: marque ao menos um"; });

    $("#btn-atualizar").addEventListener("click", () => carregarDados(true));
    $("#btn-editar").addEventListener("click", () => modoEdicao(true));
    $("#btn-concluir").addEventListener("click", () => modoEdicao(false));
    $("#btn-add").addEventListener("click", () => abrirEditor(null));
    $("#btn-restaurar").addEventListener("click", async () => {
      if (!confirm("Substituir o painel atual pelo painel padrão?")) return;
      estado.painel = await api("/api/dashboard?default=true");
      salvarPainel(); renderizar();
    });
    $("#btn-config").addEventListener("click", () => abrirConfig());

    $("#w-metrica").addEventListener("change", () => {
      const meta = estado.porId[$("#w-metrica").value];
      const antigo = $("#w-titulo").value.trim();
      if (!antigo || estado.metricas.some((m) => m.title === antigo)) $("#w-titulo").value = meta.title;
      $("#w-ajuda").textContent = meta.help;
      preencherTipos(meta.kind, $("#w-tipo").value);
      if (meta.kind === "kpi") { $("#w-largura").value = "3"; $("#w-altura").value = "P"; }
      else {
        if ($("#w-altura").value === "P") $("#w-altura").value = "M";
        if ($("#w-largura").value === "3") $("#w-largura").value = "6";
      }
    });
    $("#form-widget").addEventListener("submit", salvarEditor);
    $("#w-cancelar").addEventListener("click", () => $("#dlg-widget").close());

    $("#c-testar").addEventListener("click", async () => {
      resultado(true, "Testando conexão…");
      try { const r = await post("/api/test", lerFormConfig()); resultado(r.ok, r.message); }
      catch (e) { resultado(false, e.message); }
    });
    $("#c-cancelar").addEventListener("click", () => $("#dlg-config").close());
    $("#form-config").addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        await post("/api/config", lerFormConfig());
        $("#dlg-config").close();
        estado.tecnicos = [];
        carregarDados(true);
      } catch (err) { resultado(false, err.message); }
    });
  }

  // ------------------------------------------------------------ inicio
  async function iniciar() {
    if (!window.Chart) { aviso("A biblioteca de gráficos não foi carregada. Reconstrua a imagem Docker (docker compose build)."); return; }
    ligarEventos();

    const sel = $("#w-paleta");
    Object.entries(PALETAS).forEach(([k, p]) => sel.add(new Option(p.nome, k)));

    const preset = lerLocal("painel.periodo", "30");
    $("#periodo").value = preset;
    if (preset === "custom") {
      const [i, f] = lerLocal("painel.datas", ["", ""]);
      $("#inicio").value = i; $("#fim").value = f;
      if (!i || !f) { $("#periodo").value = "30"; aplicarPreset("30"); }
    } else aplicarPreset(preset);

    try {
      const [metricas, painel, cfg] = await Promise.all([api("/api/metric-list"), api("/api/dashboard"), api("/api/config")]);
      estado.metricas = metricas;
      metricas.forEach((m) => { estado.porId[m.id] = m; });
      estado.painel = painel;

      const selM = $("#w-metrica");
      const grupos = {};
      metricas.forEach((m) => {
        if (!grupos[m.group]) { grupos[m.group] = document.createElement("optgroup"); grupos[m.group].label = m.group; selM.appendChild(grupos[m.group]); }
        grupos[m.group].appendChild(new Option(m.title, m.id));
      });

      renderizar();
      if (!cfg.configured) {
        abrirConfig("Bem-vindo! Informe a URL da API e os tokens do GLPI para começar. Use \"Testar conexão\" antes de salvar.");
        return;
      }
      carregarDados(false);
    } catch (e) {
      aviso(`Erro ao iniciar o painel: ${e.message}`);
    }
  }

  iniciar();
})();
