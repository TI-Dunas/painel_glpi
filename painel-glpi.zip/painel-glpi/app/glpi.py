"""Cliente da API REST do GLPI e carga dos dados usados no painel."""
from datetime import datetime

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class GlpiError(Exception):
    pass


def parse_dt(valor):
    if not valor:
        return None
    try:
        return datetime.strptime(str(valor)[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def normalizar_url(url):
    url = (url or "").strip().rstrip("/")
    if url and "apirest.php" not in url:
        url += "/apirest.php"
    return url


class GlpiClient:
    def __init__(self, cfg):
        self.url = normalizar_url(cfg.get("glpi_url"))
        self.app_token = (cfg.get("app_token") or "").strip()
        self.user_token = (cfg.get("user_token") or "").strip()
        self.verify = bool(cfg.get("verify_ssl"))
        self.headers = None
        if not self.url:
            raise GlpiError("URL da API do GLPI nao configurada.")
        if not self.user_token:
            raise GlpiError("User Token nao configurado.")

    def _base(self):
        h = {"Content-Type": "application/json"}
        if self.app_token:
            h["App-Token"] = self.app_token
        return h

    def __enter__(self):
        h = self._base()
        h["Authorization"] = f"user_token {self.user_token}"
        try:
            r = requests.get(f"{self.url}/initSession", headers=h,
                             verify=self.verify, timeout=30)
        except requests.exceptions.SSLError:
            raise GlpiError("Erro de certificado SSL. Desmarque 'Verificar certificado SSL' "
                            "nas configuracoes (certificado vencido ou autoassinado).")
        except requests.exceptions.RequestException as e:
            raise GlpiError(f"Nao foi possivel conectar em {self.url}: {e}")
        if r.status_code != 200:
            raise GlpiError(f"Login na API recusado (HTTP {r.status_code}): {r.text[:300]}")
        self.headers = self._base()
        self.headers["Session-Token"] = r.json()["session_token"]
        try:  # garante visao de todas as entidades
            requests.post(f"{self.url}/changeActiveEntities", headers=self.headers,
                          json={"entities_id": 0, "is_recursive": True},
                          verify=self.verify, timeout=30)
        except requests.exceptions.RequestException:
            pass
        return self

    def __exit__(self, *args):
        try:
            requests.get(f"{self.url}/killSession", headers=self.headers,
                         verify=self.verify, timeout=10)
        except requests.exceptions.RequestException:
            pass

    def get(self, path, params=None):
        return requests.get(f"{self.url}/{path}", headers=self.headers, params=params,
                            verify=self.verify, timeout=180)

    def get_all(self, itemtype, passo=1000, opcional=False):
        itens, inicio = [], 0
        while True:
            r = self.get(itemtype, {"range": f"{inicio}-{inicio + passo - 1}"})
            if r.status_code == 400 and "ERROR_RANGE_EXCEED_TOTAL" in r.text:
                break
            if r.status_code not in (200, 206):
                if opcional:
                    return []
                raise GlpiError(f"Erro ao ler {itemtype} (HTTP {r.status_code}): {r.text[:300]}")
            lote = r.json()
            if not isinstance(lote, list) or not lote:
                break
            itens.extend(lote)
            inicio += len(lote)
            total = None
            faixa = r.headers.get("Content-Range", "")
            if "/" in faixa:
                try:
                    total = int(faixa.split("/")[-1])
                except ValueError:
                    pass
            if total is not None and inicio >= total:
                break
            if total is None and len(lote) < passo:
                break
        return itens


def nome_usuario(u, uid):
    nome = " ".join(x for x in [u.get("firstname"), u.get("realname")] if x)
    return nome or u.get("name") or f"Usuario {uid}"


def buscar_perfis_tecnico(g, nome_perfil):
    perfis = g.get_all("Profile")
    alvo = (nome_perfil or "Technician").strip().lower()
    ids = {p["id"] for p in perfis if str(p.get("name", "")).strip().lower() == alvo}
    if not ids:
        nomes = ", ".join(sorted(str(p.get("name")) for p in perfis))
        raise GlpiError(f"Perfil '{nome_perfil}' nao encontrado. Perfis existentes: {nomes}")
    return ids


def testar(cfg):
    with GlpiClient(cfg) as g:
        perfis = buscar_perfis_tecnico(g, cfg.get("tech_profile"))
        usuarios = {pu["users_id"] for pu in g.get_all("Profile_User")
                    if pu.get("profiles_id") in perfis}
    return (f"Conexao OK. Perfil '{cfg.get('tech_profile')}' encontrado com "
            f"{len(usuarios)} usuario(s).")


def carregar(cfg):
    with GlpiClient(cfg) as g:
        perfis = buscar_perfis_tecnico(g, cfg.get("tech_profile"))
        ids_tec = {pu["users_id"] for pu in g.get_all("Profile_User")
                   if pu.get("profiles_id") in perfis}

        tecnicos = {}
        for uid in ids_tec:
            r = g.get(f"User/{uid}")
            if r.status_code != 200:
                continue
            u = r.json()
            if u.get("is_deleted"):
                continue
            tecnicos[uid] = {"id": uid, "name": nome_usuario(u, uid),
                             "active": bool(u.get("is_active", 1))}

        chamados = {}
        for t in g.get_all("Ticket"):
            chamados[t["id"]] = {
                "id": t["id"],
                "name": t.get("name") or "",
                "status": int(t.get("status") or 0),
                "date": parse_dt(t.get("date")),
                "solvedate": parse_dt(t.get("solvedate")),
                "closedate": parse_dt(t.get("closedate")),
                "ttr": parse_dt(t.get("time_to_resolve")),
                "solve_delay": int(t.get("solve_delay_stat") or 0),
                "techs": set(),
                "refused": False,
                "waiting_validation": False,
            }

        for tu in g.get_all("Ticket_User"):
            if (tu.get("type") == 2 and tu.get("users_id") in tecnicos
                    and tu.get("tickets_id") in chamados):
                chamados[tu["tickets_id"]]["techs"].add(tu["users_id"])

        for s in g.get_all("ITILSolution", opcional=True):
            if s.get("itemtype") == "Ticket" and s.get("status") == 4 and s.get("items_id") in chamados:
                chamados[s["items_id"]]["refused"] = True

        for v in g.get_all("TicketValidation", opcional=True):
            if v.get("status") == 2 and v.get("tickets_id") in chamados:
                chamados[v["tickets_id"]]["waiting_validation"] = True

    return {
        "techs": tecnicos,
        "tickets": [t for t in chamados.values() if t["techs"]],
        "unassigned_new": sum(1 for t in chamados.values() if not t["techs"] and t["status"] == 1),
    }
