"""Painel de Atendimento GLPI - servidor web."""
import json
import os
import secrets
import threading
import time
from datetime import datetime

from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles

import glpi
import metrics

DATA_DIR = os.environ.get("DATA_DIR", "/data")
ARQ_CONFIG = os.path.join(DATA_DIR, "config.json")
ARQ_PAINEL = os.path.join(DATA_DIR, "dashboard.json")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")

PANEL_USER = os.environ.get("PANEL_USER", "admin")
PANEL_PASSWORD = os.environ.get("PANEL_PASSWORD", "")

CONFIG_PADRAO = {
    "glpi_url": "",
    "app_token": "",
    "user_token": "",
    "verify_ssl": False,
    "tech_profile": "Technician",
    "cache_minutes": 10,
}

seguranca = HTTPBasic(auto_error=False)


def autenticar(cred: HTTPBasicCredentials = Depends(seguranca)):
    if not PANEL_PASSWORD:
        return
    if cred is None or not (secrets.compare_digest(cred.username, PANEL_USER)
                            and secrets.compare_digest(cred.password, PANEL_PASSWORD)):
        raise HTTPException(401, "Acesso negado", headers={"WWW-Authenticate": 'Basic realm="Painel GLPI"'})


app = FastAPI(title="Painel GLPI", dependencies=[Depends(autenticar)])
app.mount("/static", StaticFiles(directory=STATIC), name="static")


# ------------------------------------------------------------------ arquivos
def ler_json(caminho, padrao):
    try:
        with open(caminho, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return padrao


def gravar_json(caminho, dados):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
    os.replace(tmp, caminho)


def ler_config():
    cfg = dict(CONFIG_PADRAO)
    cfg.update(ler_json(ARQ_CONFIG, {}))
    return cfg


# ------------------------------------------------------------------ cache
CACHE = {"dados": None, "ts": 0.0, "carregado_em": None}
TRAVA = threading.Lock()


def obter_dados(forcar=False):
    cfg = ler_config()
    with TRAVA:
        validade = max(1, int(cfg.get("cache_minutes") or 10)) * 60
        if CACHE["dados"] is not None and not forcar and time.time() - CACHE["ts"] < validade:
            return CACHE["dados"]
        dados = glpi.carregar(cfg)
        CACHE.update(dados=dados, ts=time.time(), carregado_em=datetime.now())
        return dados


def limpar_cache():
    with TRAVA:
        CACHE.update(dados=None, ts=0.0, carregado_em=None)


# ------------------------------------------------------------------ rotas
@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC, "index.html"))


@app.get("/api/config")
def api_config():
    cfg = ler_config()
    return {
        "glpi_url": cfg["glpi_url"],
        "verify_ssl": cfg["verify_ssl"],
        "tech_profile": cfg["tech_profile"],
        "cache_minutes": cfg["cache_minutes"],
        "app_token_set": bool(cfg["app_token"]),
        "user_token_set": bool(cfg["user_token"]),
        "configured": bool(cfg["glpi_url"] and cfg["user_token"]),
    }


def mesclar(novo):
    cfg = ler_config()
    for campo in ("glpi_url", "tech_profile"):
        if campo in novo:
            cfg[campo] = str(novo[campo] or "").strip()
    for campo in ("app_token", "user_token"):  # vazio = manter o atual
        valor = str(novo.get(campo) or "").strip()
        if valor:
            cfg[campo] = valor
    if novo.get("clear_app_token"):
        cfg["app_token"] = ""
    if "verify_ssl" in novo:
        cfg["verify_ssl"] = bool(novo["verify_ssl"])
    if "cache_minutes" in novo:
        try:
            cfg["cache_minutes"] = max(1, int(novo["cache_minutes"]))
        except (TypeError, ValueError):
            pass
    cfg["glpi_url"] = glpi.normalizar_url(cfg["glpi_url"])
    return cfg


@app.post("/api/config")
def api_config_salvar(novo: dict):
    gravar_json(ARQ_CONFIG, mesclar(novo))
    limpar_cache()
    return api_config()


@app.post("/api/test")
def api_testar(novo: dict):
    try:
        return {"ok": True, "message": glpi.testar(mesclar(novo))}
    except glpi.GlpiError as e:
        return {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "message": f"Erro inesperado: {e}"}


@app.get("/api/metric-list")
def api_metricas():
    return metrics.METRICS


@app.get("/api/data")
def api_dados(start: str, end: str, techs: str = "", refresh: bool = False):
    try:
        inicio = datetime.strptime(start, "%Y-%m-%d")
        fim = datetime.strptime(end, "%Y-%m-%d").replace(hour=23, minute=59, second=59)
    except ValueError:
        raise HTTPException(400, "Datas invalidas (use AAAA-MM-DD).")
    try:
        dados = obter_dados(forcar=refresh)
    except glpi.GlpiError as e:
        raise HTTPException(502, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"Erro ao consultar o GLPI: {e}")
    ids = [int(x) for x in techs.split(",") if x.strip().isdigit()]
    lista = sorted(dados["techs"].values(), key=lambda u: u["name"].lower())
    return {
        "loaded_at": CACHE["carregado_em"].strftime("%d/%m/%Y %H:%M") if CACHE["carregado_em"] else "",
        "techs": lista,
        "metrics": metrics.calcular(dados, inicio, fim, ids),
    }


def w(metric, type_, width, height="M", title=None, palette="padrao", legend=True, values=False):
    meta = next(x for x in metrics.METRICS if x["id"] == metric)
    return {"id": secrets.token_hex(4), "metric": metric, "type": type_, "width": width,
            "height": height, "title": title or meta["title"], "palette": palette,
            "legend": legend, "values": values}


def painel_padrao():
    return {"widgets": [
        w("kpi_abertos", "card", 3, "P", palette="padrao"),
        w("kpi_em_aberto", "card", 3, "P", palette="azul"),
        w("kpi_pendentes", "card", 3, "P", palette="quente"),
        w("kpi_aguardando", "card", 3, "P", palette="pastel"),
        w("kpi_sla_expirado", "card", 3, "P", palette="alerta"),
        w("kpi_fechados", "card", 3, "P", palette="verde"),
        w("kpi_reabertos", "card", 3, "P", palette="quente"),
        w("kpi_sla_percentual", "card", 3, "P", palette="verde"),
        w("status_geral", "doughnut", 4, palette="semaforo", values=True),
        w("sla_geral", "pie", 4, palette="semaforo", values=True),
        w("em_aberto_por_tecnico", "barh", 4, legend=False, values=True),
        w("status_por_tecnico", "stacked", 6, palette="semaforo"),
        w("sla_por_tecnico", "barh_stacked", 6, palette="semaforo"),
        w("evolucao", "line", 12, palette="semaforo"),
        w("reabertos_por_tecnico", "bar", 6, palette="quente", legend=False, values=True),
        w("tempo_medio_por_tecnico", "barh", 6, palette="azul", legend=False, values=True),
        w("tabela_ranking", "table", 12, "M"),
        w("tabela_sla_expirado", "table", 12, "G"),
    ]}


@app.get("/api/dashboard")
def api_painel(default: bool = False):
    if default:
        return painel_padrao()
    return ler_json(ARQ_PAINEL, None) or painel_padrao()


@app.post("/api/dashboard")
def api_painel_salvar(painel: dict):
    if not isinstance(painel.get("widgets"), list):
        raise HTTPException(400, "Formato invalido.")
    gravar_json(ARQ_PAINEL, painel)
    return {"ok": True}
