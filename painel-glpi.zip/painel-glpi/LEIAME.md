# Painel de Atendimento GLPI

Painel web com gráficos configuráveis (pizza, rosca, polar, barras, barras empilhadas,
linhas, áreas, radar, cartões e tabelas) sobre os chamados dos técnicos do GLPI.
Os dados vêm da **API REST do GLPI**, configurada pela própria tela do painel.

## 1. Instalar o Docker (Rocky / Alma / RHEL)

```bash
dnf -y install dnf-plugins-core
dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
dnf -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin
systemctl enable --now docker
```

## 2. Subir o painel

Copie a pasta `painel-glpi` para o servidor (ex.: `/opt/painel-glpi`) e rode:

```bash
cd /opt/painel-glpi
nano docker-compose.yml        # troque PANEL_PASSWORD por uma senha sua
docker compose up -d --build
firewall-cmd --permanent --add-port=8080/tcp && firewall-cmd --reload
```

Acesse `http://IP_DO_SERVIDOR:8080` com o usuário e a senha definidos no
`docker-compose.yml`.

## 3. Configurar a API (primeiro acesso)

A tela de configurações abre sozinha. Preencha:

| Campo | Onde encontrar no GLPI |
|---|---|
| URL da API | `https://IP_DO_GLPI/apirest.php` |
| App Token | Configurar > Geral > API > (cliente da API) |
| User Token | Minhas configurações > Chaves de acesso remoto > Token da API |
| Perfil dos técnicos | Nome exato do perfil, ex.: `Technician` |

Clique em **Testar conexão** e depois em **Salvar configurações**.
Se o certificado do GLPI estiver vencido, deixe **Verificar certificado SSL** desmarcado.

O cliente da API no GLPI precisa estar **ativo** e liberar o **IP do servidor do painel**.
O User Token deve ser de um usuário que enxergue **todas as entidades** e tenha leitura de
chamados, usuários e perfis (um Super-Admin dedicado à integração é o mais simples).

## 4. Personalizar os gráficos

* **Editar painel** > **Adicionar gráfico**: escolha a métrica, o tipo de gráfico, as cores,
  a largura e a altura.
* Em cada gráfico: ✎ edita, ← → muda a posição, ✕ remove.
* A paleta **Por significado (status/SLA)** usa verde para no prazo e vermelho para expirado.
* O filtro de **período** e de **técnicos** no topo vale para todos os gráficos.
* O layout fica salvo no servidor (pasta `data/`), igual para todos que acessarem.

## 5. Comandos úteis

```bash
docker compose logs -f          # ver o que está acontecendo
docker compose restart          # reiniciar
docker compose up -d --build    # aplicar atualizações do painel
```

Os dados do GLPI ficam em cache pelo tempo definido em "Atualizar dados a cada (min)".
O botão **Atualizar dados** força uma nova leitura na hora.
